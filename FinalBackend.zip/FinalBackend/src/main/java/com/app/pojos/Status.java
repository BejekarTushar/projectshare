package com.app.pojos;

public enum Status {
	
	NEW, INPROCESS, FULFILLED

}
