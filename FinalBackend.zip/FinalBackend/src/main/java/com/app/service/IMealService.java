package com.app.service;

import java.util.List;

import com.app.pojos.Meal;

public interface IMealService {
	
	Meal getMealById(Integer id);
	
	Meal addNewMeal(Meal meal);
	
	List<Meal> getMealList();
	
	Meal updateMeal(Meal m,Integer id);
	
	String deleteMeal(Integer id);

}
