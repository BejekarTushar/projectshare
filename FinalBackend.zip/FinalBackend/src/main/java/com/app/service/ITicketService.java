package com.app.service;

import com.app.pojos.Ticket;

public interface ITicketService {

	Ticket addTicket(Ticket ticket);
}
