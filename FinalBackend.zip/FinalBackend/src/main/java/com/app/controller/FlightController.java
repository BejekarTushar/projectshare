package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.FlightDto;
import com.app.pojos.Flight;
import com.app.pojos.FlightMeal;
import com.app.repo.FlightMealRepo;
import com.app.repo.FlightRepo;
import com.app.service.IAeroplaneService;
import com.app.service.IFlightService;

@RestController
@RequestMapping("/flights")
public class FlightController {
	public FlightController() {
		System.out.println("Inside flight controller"+getClass());
			}
	
	@Autowired
	private IAeroplaneService aservice;
	@Autowired
	private IFlightService fservice;
	@Autowired
	private FlightMealRepo fmrepo;
	@Autowired
	private FlightRepo frepo;
	
//	Showing the list of flights
//	@GetMapping
//	public List<Flight> flightList(){
//		return fservice.getFlightList();
//	}
	
	//Adding new flight
	@PostMapping
	public Flight addFlight(@RequestBody FlightDto flight) {
		Flight f = fservice.addFlight(flight);
//		FlightMeal fm = new FlightMeal(); 
//		fm.setFlight(f);
//		fmrepo.save(fm);
		return f;
	}
	
	//Updateing the existing flight
	@PutMapping("/{id}")
	public Flight updateFlight(@RequestBody Flight flight,@PathVariable Integer id) {
		return fservice.updateFlight(flight,id);
		
	}
	
	//Deleting the existing flight
//	@DeleteMapping("/{id}")
//	public String deleteFlight(@PathVariable Integer id) {
//		String mesg = fservice.deleteFlight(id);
//		return mesg;
//	}
}
