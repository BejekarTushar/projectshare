package com.app.service;

import java.util.List;

import com.app.pojos.City;


public interface ICityService {
	

	
	List<City> getAllCities();

}
