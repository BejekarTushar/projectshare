package com.app.pojos;

public enum Role {
	
	ROLE_ADMIN, ROLE_USER, ROLE_FLIGHTMANAGER, ROLE_CRM

}
